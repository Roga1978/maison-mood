
Maison Mood – Site e-commerce 100% gratuit (statique)
====================================================

• Aucune plateforme nécessaire (pas de Shopify/Wix). 
• Catalogue + panier (LocalStorage) + checkout par e-mail (mailto).
• Vous recevez la commande par e-mail et envoyez ensuite un lien de paiement PayPal/Stripe au client.

Déploiement gratuit conseillé : Netlify
---------------------------------------
1) Créez un compte gratuit sur https://www.netlify.com/.
2) Cliquez sur "Add new site" > "Deploy manually".
3) Glissez-déposez tout le dossier ZIP que je vous fournis.
4) Le site sera immédiatement en ligne sous une URL *.netlify.app.

Astuce : pour activer PayPal
----------------------------
• Créez un "bouton de paiement hébergé" PayPal et récupérez votre lien. 
• Vous pouvez remplacer la logique "mailto" par une redirection vers votre lien PayPal dans checkout.html.

Mentions importantes
--------------------
• Ce site n'automatise pas l'envoi des commandes au fournisseur (dropshipping manuel).
• Pour l'automatisation complète, une solution payante e-commerce sera nécessaire.
