
const CART_KEY = 'mm_cart_v1';
async function loadProducts(){ const res = await fetch('products.json'); return res.json(); }
function fmtEUR(n){return new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'}).format(n);}
function getCart(){ try{ return JSON.parse(localStorage.getItem(CART_KEY)||'[]'); }catch(e){ return []; } }
function saveCart(cart){ localStorage.setItem(CART_KEY, JSON.stringify(cart)); renderCartCount(); }
function addToCart(id, qty=1){ const cart = getCart(); const item = cart.find(i=>i.id===id); if(item){ item.qty += qty; } else { cart.push({id, qty}); } saveCart(cart); alert('Ajouté au panier ✅'); }
function removeFromCart(id){ let cart = getCart().filter(i=>i.id!==id); saveCart(cart); renderCart(); }
function renderCartCount(){ const el = document.querySelector('.cart-count'); if(!el) return; const total = getCart().reduce((s,i)=>s+i.qty,0); el.textContent = total; }
async function getCartDetailed(){ const prods = await loadProducts(); const map = Object.fromEntries(prods.map(p=>[p.id,p])); const cart = getCart().map(i=>({...map[i.id], qty:i.qty})).filter(Boolean); return cart; }
async function renderCatalog(selector='.grid'){ const container = document.querySelector(selector); if(!container) return; const products = await loadProducts(); container.innerHTML = products.map(p=>`
  <div class="card">
    <img src="${p.image}" alt="${p.title}">
    <div class="p">
      <div style="font-weight:700">${p.title}</div>
      <div class="small">${p.category}</div>
      <div class="price">${fmtEUR(p.price)}</div>
      <div style="margin-top:8px;display:flex;gap:8px">
        <a class="btn" href="product.html?id=${p.id}">Voir</a>
        <button class="btn fill" onclick="addToCart('${p.id}',1)">Ajouter</button>
      </div>
    </div>
  </div>`).join(''); }
async function renderProductPage(){ const params = new URLSearchParams(location.search); const id = params.get('id'); if(!id) return; const products = await loadProducts(); const p = products.find(x=>x.id===id); if(!p) return; document.querySelector('#pimg').src = p.image; document.querySelector('#ptitle').textContent = p.title; document.querySelector('#pcat').textContent = p.category; document.querySelector('#pprice').textContent = fmtEUR(p.price); document.querySelector('#pdesc').textContent = p.description; document.querySelector('#add').onclick = ()=>addToCart(p.id,1); }
async function renderCart(){ const tbody = document.querySelector('#cartbody'); const tfoot = document.querySelector('#cartfoot'); if(!tbody || !tfoot) return; const items = await getCartDetailed(); let total = 0; tbody.innerHTML = items.map(it=>{ const line = it.price*it.qty; total += line; return `<tr>
  <td><img src="${it.image}" style="width:60px;height:60px;object-fit:cover;border-radius:8px;margin-right:8px;vertical-align:middle"> ${it.title}</td>
  <td>${fmtEUR(it.price)}</td>
  <td>${it.qty}</td>
  <td>${fmtEUR(line)}</td>
  <td><button class="btn" onclick="removeFromCart('${it.id}')">Supprimer</button></td>
</tr>` }).join(''); tfoot.innerHTML = `<tr><td colspan="3">Total</td><td>${fmtEUR(total)}</td><td></td></tr>`; document.querySelector('#checkoutBtn')?.addEventListener('click', ()=>{ location.href = 'checkout.html'; }); }
function mailtoOrderPayload(items, customer){ const lines = items.map(i=>`- ${i.title} x${i.qty} = ${i.price*i.qty} €`).join('%0D%0A'); const total = items.reduce((s,i)=>s+i.price*i.qty,0).toFixed(2); const subject = encodeURIComponent('Nouvelle commande Maison Mood'); const body = `Bonjour,%0D%0A%0D%0AJe souhaite passer commande :%0D%0A${lines}%0D%0A%0D%0ATotal: ${total} €%0D%0A%0D%0ALivraison:%0D%0ANom: ${customer.name}%0D%0AAdresse: ${customer.addr}%0D%0ATéléphone: ${customer.phone}%0D%0AEmail: ${customer.email}%0D%0A%0D%0AMerci.`; return `mailto:${encodeURIComponent(customer.to||'contact@exemple.com')}?subject=${subject}&body=${body}`; }
async function initCheckout(){ const form = document.querySelector('#checkoutForm'); const list = document.querySelector('#checkoutList'); const items = await getCartDetailed(); list.innerHTML = items.map(i=>`<li>${i.title} × ${i.qty} — ${fmtEUR(i.price*i.qty)}</li>`).join(''); form.addEventListener('submit', e=>{ e.preventDefault(); const customer = { name: form.name.value, addr: form.addr.value, phone: form.phone.value, email: form.email.value, to: form.to.value }; const url = mailtoOrderPayload(items, customer); window.location.href = url; }); }
document.addEventListener('DOMContentLoaded', renderCartCount);
